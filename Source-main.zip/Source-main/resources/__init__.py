from .blacklist import blacklisted_users
LIST = {}
DEVLIST = [94882169, 45918006]
