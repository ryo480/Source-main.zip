from telethon.tl import functions as fun

delattr(fun.account, "DeleteAccountRequest") 